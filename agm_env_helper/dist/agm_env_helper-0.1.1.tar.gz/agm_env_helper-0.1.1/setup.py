from setuptools import setup

setup(name='agm_env_helper',
      version='0.1.1',
      description='Custom env helper',
      packages=['agm_env_helper'],
      author_email='alexgeniusman@gmail.com',
      zip_safe=False)
